<?php

class SQLite 
{
    private $pdo;

    /**
     * 构造函数：连接数据库并初始化配置
     * @param string $dbPath 数据库文件路径
     */
    public function __construct($dbPath) 
    {
        try {
            // 1. 建立 PDO 连接
            $this->pdo = new PDO('sqlite:' . $dbPath);

            // 2. 设置 PDO 核心属性 (最佳实践)
            // 开启异常模式，出错时直接抛出异常，而不是默默失败
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // 默认返回关联数组 (键值对)，而不是数字索引数组
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            // 3. 【核心优化】开启 WAL 模式 (Write-Ahead Logging)
            // 大幅提升 SQLite 的并发读写性能，减少锁冲突
            $this->pdo->exec('PRAGMA journal_mode=WAL;');

            // 4. 【核心优化】设置忙等待超时时间 (毫秒)
            // 当发生写锁冲突时，等待 5 秒而不是直接报错 "database is locked"
            $this->pdo->exec('PRAGMA busy_timeout=5000;');

        } catch (PDOException $e) {
            // 捕获连接异常并抛出更友好的错误信息
            throw new Exception("SQLite 数据库连接失败: " . $e->getMessage());
        }
    }

    /**
     * 查询多条数据 (SELECT)
     * @param string $sql SQL 语句 (使用 ? 或 :name 作为占位符)
     * @param array $params 绑定的参数
     * @return array
     */
    public function query($sql, $params = []) 
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 查询单条数据
     */
    public function queryOne($sql, $params = []) 
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    /**
     * 执行增删改语句 (INSERT, UPDATE, DELETE)
     * @return int 返回受影响的行数
     */
    public function execute($sql, $params = []) 
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    /**
     * 获取最后一次插入的 ID
     */
    public function lastInsertId() 
    {
        return $this->pdo->lastInsertId();
    }

    /**
     * 获取原生 PDO 实例 (用于执行事务等高级操作)
     */
    public function getPdo() 
    {
        return $this->pdo;
    }
}