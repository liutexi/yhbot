<?php

//记录bot_id
define('BOT_ID', '388598685');

// 自动加载classes中的类
spl_autoload_register(function ($class_name) {
    $relative_path = str_replace(['\\', '_'], DIRECTORY_SEPARATOR, $class_name);
    $file = __DIR__ . '/classes/' . $relative_path . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});
$router = new Router();
$basePath = $_SERVER['SCRIPT_NAME'];
$basePath = str_replace('\\', '/', $basePath); // 兼容 Windows
// 将包含 index.php 的路径设置为 BasePath
$router->setBasePath($basePath);


//数据库
$dbPath = __DIR__ . '/../../database/one.db'; 
try {
    // 实例化 SQLite 类 (此时会自动触发 __construct 连接数据库)
    $db = new SQLite($dbPath);
} catch (Exception $e) {
    die("系统错误：" . $e->getMessage());
}


// 路由
$router->get('/', function() {
    echo 'Hello World!';
});

$router->post('/notify', function()use ($db) {
       $rawData = file_get_contents('php://input');
    // 解析 JSON
    $data = json_decode($rawData, true);
    //校验 JSON 是否有效
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
        return;
    }
    //安全提取嵌套数据 (使用 ?? 防止 Undefined array key 警告)
    $header  = $data['header'] ?? [];
    $event   = $data['event'] ?? [];
    $sender  = $event['sender'] ?? [];
    $chat    = $event['chat'] ?? [];
    $message = $event['message'] ?? [];
    $content = $message['content'] ?? [];
    // 构建要插入数据库的关联数组
    // 键名必须与数据库字段名完全一致
    $insertData = [
        'raw_json'          => $rawData, // 保存原始 JSON 以备不时之需
        'version'           => $data['version'] ?? null,
        'event_id'          => $header['eventId'] ?? null,
        'event_type'        => $header['eventType'] ?? null,
        'event_time'        => $header['eventTime'] ?? null,
        'sender_id'         => $sender['senderId'] ?? null,
        'sender_type'       => $sender['senderType'] ?? null,
        'sender_user_level' => $sender['senderUserLevel'] ?? null,
        'sender_nickname'   => $sender['senderNickname'] ?? null,
        'sender_avatar_url' => $sender['senderAvatarUrl'] ?? null,
        'group_id'          => $chat['chatType']=='group' ? $chat['chatId'] : null, // chatId 在群聊中即为 group_id
        'bot_id'            => BOT_ID,                   
        'chat_type'         => $chat['chatType'] ?? null,
        'msg_id'            => $message['msgId'] ?? null,
        'msg_parent_id'     => $message['parentId'] ?? null,
        'send_time'         => $message['sendTime'] ?? null,
        'content_type'      => $message['contentType'] ?? null,
        'content_text'      => $content['text'] ?? null,
        'content_parent'    => $content['parent'] ?? null,
        'instruction_id'    => $message['instructionId'] ?? null,
        'instruction_name'  => $message['instructionName'] ?? null,
        'command_id'        => $message['commandId'] ?? null,
        'command_name'      => $message['commandName'] ?? null,
    ];
	try {
        $columns = array_keys($insertData);
        $placeholders = array_map(fn($col) => ":$col", $columns); 
        $sql = "INSERT INTO notify_log (" . implode(',', $columns) . ") 
                VALUES (" . implode(',', $placeholders) . ")";
       $result = $db->execute($sql, $insertData);
		 // ===== 调试信息 =====
        echo "1. execute 返回值: " . $result . "<br>";
        echo "2. 数据库文件路径: " . realpath($dbPath) . "<br>";
        echo "3. 数据库文件大小: " . filesize($dbPath) . " 字节<br>";
        echo "4. WAL 文件存在: " . (file_exists($dbPath . '-wal') ? '是' : '否') . "<br>";
        
        // 强制 checkpoint
        $db->getPdo()->exec('PRAGMA wal_checkpoint(FULL);');
        echo "5. WAL checkpoint 完成<br>";
        
        // 立即回查
        $check = $db->query("SELECT COUNT(*) as total FROM notify_log");
        echo "6. 数据库总记录数: " . $check[0]['total'] . "<br>";
        
        $lastRow = $db->query("SELECT id, event_type, content_text FROM notify_log ORDER BY id DESC LIMIT 1");
        echo "7. 最后一条记录: <pre>" . print_r($lastRow, true) . "</pre>";
        // ===== 调试结束 =====
		
		
		
        http_response_code(200);
        echo json_encode(['status' => 'success']);
    } catch (Exception $e) {
        // 记录错误并返回 500
        error_log("Notify DB Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Database insert failed']);
    }
});

$router->run(); 